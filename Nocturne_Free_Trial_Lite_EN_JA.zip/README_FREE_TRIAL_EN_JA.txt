========================================================================
Nocturne & Button-Eyed Doll — Free Trial Lite Edition (0 JPY / 無料体験版)
========================================================================
⭐ If you enjoy this free trial, please take 2 seconds to give a free Star / Heart!
⭐ 気に入っていただけましたら、ぜひ無料の Star / スキ で応援をお願いします！
- GitHub Star: https://github.com/pathetic777/nocturne-live2d-companion
- BOOTH Free Heart (スキ): https://nocturne-live2d.booth.pm/items/9027923
- BOOTH Full Edition (2,000 JPY): https://nocturne-live2d.booth.pm/items/9027370
- Custom Live2D Commission ($15~$25): https://ko-fi.com/282831/commissions

[How to Run / 起動方法]
Double-click `Nocturne_Free_Trial_Lite_EN_JA.html` to open in any browser.
`Nocturne_Free_Trial_Lite_EN_JA.html` をダブルクリックしてブラウザで開いてください。
